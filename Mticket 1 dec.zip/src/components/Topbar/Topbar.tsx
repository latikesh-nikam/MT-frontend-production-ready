import { useContext } from 'react';
import { Box } from '@mui/material';
import { Button } from '@mui/material';
import Profile from '../Profile/Profile';
import { Header } from './topbar.style';
import DirectionsBusFilledIcon from '@mui/icons-material/DirectionsBusFilled';
import { LocalisationContext } from '../../hoc/Localization/LocalisationProvider';
import { ILocalisationContext } from '../../hoc/Localization/localisationProvider.types';

function Topbar() {
  const { localisation, updateLocalisation } = useContext(
    LocalisationContext,
  ) as ILocalisationContext;
  const { localString } = localisation;
  return (
    <Header>
      <Box className="logoDiv">
        <DirectionsBusFilledIcon className="icon" />
        <h2>{localString['Mticket']}</h2>
        <Box className="navElements">
          <Button className="buttonText">
            {localString['recentBookings']}
          </Button>
          <Button className="buttonText">{localString['bookTicket']}</Button>
        </Box>
      </Box>
      <Profile />
    </Header>
  );
}
export default Topbar;
