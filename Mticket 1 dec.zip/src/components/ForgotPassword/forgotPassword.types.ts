export default interface IForgotPasswordProps {
  email: string;
  newPassword: string;
  confirmPassword: string;
  securityQuestion: string;
  securityQuestionAnswer: string;
}
