import { PropsWithChildren } from 'react';

export interface ILocalisationProviderProps extends PropsWithChildren {}
