export enum languageConstants {
  'english' = 'en',
  'hindi' = 'hn',
}
