import DirectionsBusFilledIcon from '@mui/icons-material/DirectionsBusFilled';
import Profile from '../Profile/Profile';
import { Header, LogoDiv } from './topbar.style';

function Topbar() {
  return (
    <Header>
      <LogoDiv>
        <DirectionsBusFilledIcon fontSize="large" />
        <h2>MTicket</h2>
      </LogoDiv>
      <Profile />
    </Header>
  );
}
export default Topbar;
