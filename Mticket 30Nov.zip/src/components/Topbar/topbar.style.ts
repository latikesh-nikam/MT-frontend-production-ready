import { makeStyles, styled } from '@mui/styles';
export const useStyles: any = makeStyles((theme: any) => ({
  container: {
    backgroundColor: theme.palette?.background?.blue,
    '&data-hasDeviceResponsive=true': {},
  },
}));

export const Header = styled('div')({
  backgroundColor: '#175cd3',
  paddingRight: '1rem',
  paddingLeft: '1rem',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  color: 'white',
});

export const LogoDiv = styled('div')({
  display: 'flex',
  alignItems: 'center',
  gap: '1rem',
});
