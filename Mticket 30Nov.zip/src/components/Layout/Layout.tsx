import { Toolbar } from '@mui/material';
import { Route, Routes } from 'react-router-dom';
import Auth from '../../Pages/Auth/Auth';
import ForgotPassword from '../ForgotPassword/ForgotPassword';
import Signup from '../Signup/Signup';
import Topbar from '../Topbar/Topbar';

const Layout = () => {
  return (
    <Routes>
      <Route path="/" element={<Auth />}>
        <Route index element={<Signup />} />
        <Route path="/forgotPassword" element={<ForgotPassword />} />
      </Route>
      <Route path="/topbar" element={<Topbar />}></Route>
    </Routes>
  );
};

export default Layout;
