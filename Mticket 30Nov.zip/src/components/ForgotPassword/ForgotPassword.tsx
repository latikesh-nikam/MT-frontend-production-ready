import { Fragment } from 'react';
import { useEffect } from 'react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Controller } from 'react-hook-form';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Button } from '@mui/material';
import { FormControl } from '@mui/material';
import { InputLabel } from '@mui/material';
import { MenuItem } from '@mui/material';
import { Paper } from '@mui/material';
import { Select } from '@mui/material';
import { TextField } from '@mui/material';
import IForgotPasswordProps from './forgotPassword.types';
import { getData } from '../../services/http';
import { postData } from '../../services/http';
import { IQuestionProps } from '../Signup/Signup.types';
import { ButtonDiv } from './forgotPassword.style';
import { FormContainer } from './forgotPassword.style';
import { Heading } from './forgotPassword.style';
import { LinkDiv } from './forgotPassword.style';
import { MainBox } from './forgotPassword.style';
import { MainDivBox } from './forgotPassword.style';
import { useStyles } from './forgotPassword.style';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';

const ForgotPassword = () => {
  const [questions, setQuestions] = useState<IQuestionProps[]>([]);
  const { t } = useTranslation();
  const classes = useStyles();
  const required = t('required');
  const emailMessage = t('emailMessage');
  const minLengthPassword = t('minLengthSix');
  const passwordValidator = t('passwordValidation');

  const forgotPasswordSchema = Yup.object({
    email: Yup.string().required(required).email(emailMessage),
    newPassword: Yup.string().required(required).min(6, minLengthPassword),
    confirmPassword: Yup.string()
      .required(required)
      .min(6, minLengthPassword)
      .oneOf([Yup.ref('newPassword'), null], passwordValidator),
    securityQuestion: Yup.string().required(required),
    securityQuestionAnswer: Yup.string().required(required),
  });

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<IForgotPasswordProps>({
    defaultValues: {
      email: '',
      newPassword: '',
      confirmPassword: '',
      securityQuestion: '',
      securityQuestionAnswer: '',
    },
    resolver: yupResolver(forgotPasswordSchema),
  });

  const submit = async (data: any) => {
    console.log(data, 'data');
    const response = await postData('auth/forgot-password', data);
    console.log(response, 'response');
    reset({
      email: '',
      newPassword: '',
      confirmPassword: '',
      securityQuestion: '',
      securityQuestionAnswer: '',
    });
  };

  const onSubmitHandler = () => {
    handleSubmit(data => submit(data));
  };

  const getSecurityQuestions = async () => {
    const response = await getData('security');
    setQuestions(response);
  };

  useEffect(() => {
    getSecurityQuestions();
  }, []);

  return (
    <Fragment>
      <Paper elevation={3}>
        <MainDivBox>
          <FormContainer>
            <Heading>{t('forgotPassword')}</Heading>
            <MainBox>
              <form onSubmit={onSubmitHandler}>
                <Controller
                  name="email"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label={t('enterEmail')}
                      variant="outlined"
                      fullWidth
                      error={!!errors.email}
                      helperText={errors.email ? errors.email?.message : ''}
                      margin="dense"
                      size="small"
                    />
                  )}
                />
                <Controller
                  name="securityQuestion"
                  control={control}
                  defaultValue={''}
                  render={({ field }) => (
                    <Fragment>
                      <FormControl
                        sx={{ marginTop: '0.5rem', minWidth: '100%' }}>
                        <InputLabel
                          id="securityQuestion-label"
                          className={classes.selectInput}>
                          {t('selectSecurityQuestion')}
                        </InputLabel>
                        <Select
                          {...field}
                          labelId="securityQuestion-label"
                          id="securityQuestions"
                          label="Select Security Question"
                          error={!!errors.securityQuestion}
                          margin="dense"
                          size="small">
                          {questions &&
                            questions.map((question: IQuestionProps) => {
                              return (
                                <MenuItem
                                  value={question._id}
                                  key={question._id}>
                                  {question.question}
                                </MenuItem>
                              );
                            })}
                        </Select>
                      </FormControl>
                    </Fragment>
                  )}
                />
                <Controller
                  name="securityQuestionAnswer"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label={t('enterSecurityQuestionAnswer')}
                      variant="outlined"
                      fullWidth
                      error={!!errors.securityQuestionAnswer}
                      helperText={
                        errors.securityQuestionAnswer
                          ? errors.securityQuestionAnswer?.message
                          : ''
                      }
                      margin="dense"
                      size="small"
                    />
                  )}
                />
                <Controller
                  name="newPassword"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label={t('enterNewPassword')}
                      variant="outlined"
                      fullWidth
                      error={!!errors.newPassword}
                      helperText={
                        errors.newPassword ? errors.newPassword?.message : ''
                      }
                      margin="dense"
                      size="small"
                      type="password"
                    />
                  )}
                />
                <Controller
                  name="confirmPassword"
                  control={control}
                  defaultValue=""
                  render={({ field }) => (
                    <TextField
                      {...field}
                      label={t('confirmNewPassword')}
                      variant="outlined"
                      fullWidth
                      error={!!errors.confirmPassword}
                      helperText={
                        errors.confirmPassword
                          ? errors.confirmPassword?.message
                          : ''
                      }
                      margin="dense"
                      size="small"
                      type="password"
                    />
                  )}
                />
                <ButtonDiv>
                  <Button type="submit" fullWidth variant="contained">
                    {t('updatePassword')}
                  </Button>
                </ButtonDiv>
              </form>
            </MainBox>
            <LinkDiv>
              <Link to="/">{t('backToLogin')}</Link>
            </LinkDiv>
          </FormContainer>
        </MainDivBox>
      </Paper>
    </Fragment>
  );
};
export default ForgotPassword;
