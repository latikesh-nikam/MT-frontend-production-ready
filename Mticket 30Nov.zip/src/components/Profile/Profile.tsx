import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AccountCircleSharpIcon from '@mui/icons-material/AccountCircleSharp';
import Button from '@mui/material/Button';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import { ButtonItems } from './profile.style';
import { ProfileContainer } from './profile.style';
import { ProfileDetails } from './profile.style';
import { useStyles } from './profile.style';

function Profile() {
  const [profile, setProfile] = useState(false);
  const navigate = useNavigate();
  const classes = useStyles();

  const handleLogout = () => {
    navigate('/');
  };

  return (
    <ProfileContainer>
      <div>
        <div className={classes.accountIcon} onClick={() => setProfile(true)}>
          <AccountCircleSharpIcon fontSize="large" />
        </div>
      </div>

      {profile && (
        <div
          className={classes.profileDetailsContainer}
          onClick={event => {
            if (event.target === event.currentTarget) {
              setProfile(false);
            }
          }}>
          <ProfileDetails>
            <Button
              className={classes.settingsButton}
              onClick={() => {
                navigate('/home/changePassword');
                setProfile(false);
              }}>
              <ButtonItems>
                <ManageAccountsIcon className={classes.icon} />
                Settings
              </ButtonItems>
            </Button>
            <Button className={classes.logoutButton} onClick={handleLogout}>
              <ButtonItems>
                <ExitToAppIcon className={classes.icon} />
                Logout
              </ButtonItems>
            </Button>
          </ProfileDetails>
        </div>
      )}
    </ProfileContainer>
  );
}
export default Profile;
