import { styled } from '@mui/styles';
import { makeStyles } from '@mui/styles';

export const useStyles: any = makeStyles((theme: any) => ({
  icon: {
    marginTop: '0.2rem',
  },

  accountIcon: {
    cursor: 'pointer',
    fontSize: '1rem',
    color: 'white',
  },

  profileDetailsContainer: {
    position: 'fixed',
    top: 0,
    right: 0,
    left: 0,
    bottom: 0,
    backgroundColor: 'rgba(224, 223, 223, 0.63)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    zIndex: 4,
  },
  settingsButton: {
    outline: 'none',
    cursor: 'pointer',
    fontWeight: 'bolder',
    borderRadius: '4px',
    padding: '0.25rem 0.5rem',
    backgroundColor: 'green',
    border: 'thin solid green',
    transition: 'all linear 0.4s',
  },
  logoutButton: {
    outline: 'none',
    cursor: 'pointer',
    fontWeight: 'bolder',
    borderRadius: '4px',
    padding: '0.25rem 0.5rem',
    backgroundColor: 'red',
    transition: 'all linear 0.4s',
    border: 'thin solid red',
  },
}));
export const ProfileContainer = styled('div')({
  display: 'flex',
  alignItems: 'flexEnd',
  flexDirection: 'column',
  padding: '0.5rem',
});
export const ProfileDetailsContainer = styled('div')({
  position: 'fixed',
  top: 0,
  right: 0,
  left: 0,
  bottom: 0,
  backgroundColor: 'rgba(224, 223, 223, 0.63)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'flex-end',
  zIndex: 4,
});
export const ProfileDetails = styled('div')({
  boxShadow: 'rgba(99, 99, 99, 0.2) 0px 2px 8px 0px',
  position: 'absolute',
  top: '12%',
  width: '10%',
  backgroundColor: 'transparent',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '0.5rem',
  gap: '0.5rem',
});
export const Actions = styled('div')({
  padding: 0,
  textAlign: 'center',
});
export const ButtonItems = styled('div')({
  display: 'flex',
  gap: '1rem',
});
