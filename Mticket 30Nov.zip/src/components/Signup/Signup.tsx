import { Fragment } from 'react';
import { useEffect } from 'react';
import { useRef } from 'react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { Controller } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import ReCAPTCHA from 'react-google-recaptcha';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';
import { toast } from 'react-toastify';
import { Button } from '@mui/material';
import { FormControl } from '@mui/material';
import { FormControlLabel } from '@mui/material';
import { FormLabel } from '@mui/material';
import { InputLabel } from '@mui/material';
import { MenuItem } from '@mui/material';
import { Paper } from '@mui/material';
import { Radio } from '@mui/material';
import { RadioGroup } from '@mui/material';
import { Select } from '@mui/material';
import { TextField } from '@mui/material';
import { getData } from '../../services/http';
import { postData } from '../../services/http';
import { ISignupProps } from './Signup.types';
import { IQuestionProps } from './Signup.types';
import { ButtonDiv } from './signup.style';
import { FormContainer } from './signup.style';
import { Heading } from './signup.style';
import { LinkDiv } from './signup.style';
import { MainBox } from './signup.style';
import { MainDivBox } from './signup.style';
import { RecaptchaBox } from './signup.style';
import { Row } from './signup.style';
import { useStyles } from './signup.style';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';

const Signup = () => {
  const [questions, setQuestions] = useState<IQuestionProps[]>([]);
  const captchaRef = useRef<any>(null);
  const classes = useStyles();
  const { t } = useTranslation();
  const required = t('required');
  const emailMessage = t('emailMessage');
  const minLengthPassword = t('minLengthSix');
  const minLengthPhone = t('minLengthTen');
  const maxLengthPhone = t('maxLengthTen');
  const passwordValidator = t('passwordValidation');
  const [captchaToken, setCaptchaToken] = useState('');

  const signUpSchema = Yup.object({
    name: Yup.string().required(required),
    email: Yup.string().required(required).email(emailMessage),
    password: Yup.string().required(required).min(6, minLengthPassword),
    phone: Yup.string()
      .required(required)
      .min(10, minLengthPhone)
      .max(10, maxLengthPhone),
    confirmPassword: Yup.string()
      .required(required)
      .min(6, minLengthPassword)
      .oneOf([Yup.ref('password'), null], passwordValidator),
    gender: Yup.string().required(required),
    occupation: Yup.string().required(required),
    securityQuestion: Yup.string().required(required),
    securityAnswer: Yup.string().required(required),
  });

  const getSecurityQuestions = async () => {
    const response = await getData('security');
    setQuestions(response);
  };

  useEffect(() => {
    getSecurityQuestions();
  }, []);

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ISignupProps>({
    defaultValues: {
      email: '',
      name: '',
      phone: '',
      gender: '',
      occupation: '',
      password: '',
      confirmPassword: '',
      securityQuestion: '',
      securityAnswer: '',
    },
    resolver: yupResolver(signUpSchema),
  });

  const submit = async (data: any) => {
    const token = captchaRef.current.getValue();
    setCaptchaToken(token);
    data['captcha'] = captchaToken;
    try {
      const response = await postData('auth/signup', data);
      reset({
        email: '',
        name: '',
        phone: '',
        gender: '',
        occupation: '',
        password: '',
        confirmPassword: '',
        securityQuestion: '',
        securityAnswer: '',
      });
      setCaptchaToken('');
      toast.success(`${response.message}`, {
        position: toast.POSITION.TOP_RIGHT,
      });
    } catch (error) {
      toast.error(`${error}`, {
        position: toast.POSITION.TOP_RIGHT,
      });
      throw error;
    }
  };

  const onSubmitHandler = () => {
    handleSubmit(data => submit(data));
  };

  const onCaptchaChange = () => {
    const token = captchaRef.current?.getValue();
    if (token) setCaptchaToken(token as string);
  };

  return (
    <Fragment>
      <ToastContainer />
      <MainDivBox>
        <Paper elevation={3}>
          <FormContainer>
            <Heading>{t('signUp')}</Heading>
            <MainBox>
              <form onSubmit={onSubmitHandler}>
                <Row>
                  <Controller
                    name="name"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('enterName')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.name}
                        helperText={errors.name ? errors.name?.message : ''}
                        margin="dense"
                        size="small"
                      />
                    )}
                  />
                  <Controller
                    name="email"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('enterEmail')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.email}
                        helperText={errors.email ? errors.email?.message : ''}
                        margin="dense"
                        size="small"
                      />
                    )}
                  />
                </Row>
                <Row>
                  <Controller
                    name="phone"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('enterPhoneNumber')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.phone}
                        helperText={errors.phone ? errors.phone?.message : ''}
                        margin="dense"
                        size="small"
                      />
                    )}
                  />
                  <Controller
                    name="occupation"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('enterOccupation')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.occupation}
                        helperText={
                          errors.occupation ? errors.occupation?.message : ''
                        }
                        margin="dense"
                        size="small"
                      />
                    )}
                  />
                </Row>
                <Controller
                  name="gender"
                  control={control}
                  defaultValue="other"
                  render={({ field }) => (
                    <Fragment>
                      <FormLabel id="gender">{t('selectGender')}</FormLabel>
                      <RadioGroup {...field} row aria-labelledby="gender">
                        <FormControlLabel
                          value="female"
                          control={<Radio />}
                          label={t('female')}
                          name="female"
                        />
                        <FormControlLabel
                          value="male"
                          control={<Radio />}
                          label={t('male')}
                          name="male"
                        />
                        <FormControlLabel
                          value="other"
                          control={<Radio />}
                          label={t('other')}
                          name="other"
                        />
                      </RadioGroup>
                    </Fragment>
                  )}
                />
                <Row>
                  <Controller
                    name="securityQuestion"
                    control={control}
                    defaultValue={''}
                    render={({ field }) => (
                      <Fragment>
                        <FormControl
                          sx={{ marginTop: '0.5rem', minWidth: '48.5%' }}>
                          <InputLabel
                            id="securityQuestion-label"
                            className={classes.selectInput}>
                            {t('selectSecurityQuestion')}
                          </InputLabel>
                          <Select
                            {...field}
                            labelId="securityQuestion-label"
                            id="securityQuestions"
                            label="Select Security Question"
                            error={!!errors.securityQuestion}
                            margin="dense"
                            size="small">
                            {questions &&
                              questions.map((question: IQuestionProps) => {
                                return (
                                  <MenuItem
                                    value={question._id}
                                    key={question._id}>
                                    {question.question}
                                  </MenuItem>
                                );
                              })}
                          </Select>
                        </FormControl>
                      </Fragment>
                    )}
                  />
                  <Controller
                    name="securityAnswer"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('enterSecurityQuestionAnswer')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.securityAnswer}
                        helperText={
                          errors.securityAnswer
                            ? errors.securityAnswer?.message
                            : ''
                        }
                        margin="dense"
                        size="small"
                      />
                    )}
                  />
                </Row>
                <Row>
                  <Controller
                    name="password"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('enterNewPassword')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.password}
                        helperText={
                          errors.password ? errors.password?.message : ''
                        }
                        margin="dense"
                        size="small"
                        type="password"
                      />
                    )}
                  />
                  <Controller
                    name="confirmPassword"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <TextField
                        {...field}
                        label={t('confirmNewPassword')}
                        variant="outlined"
                        fullWidth
                        error={!!errors.confirmPassword}
                        helperText={
                          errors.confirmPassword
                            ? errors.confirmPassword?.message
                            : ''
                        }
                        margin="dense"
                        size="small"
                        type="password"
                      />
                    )}
                  />
                </Row>
                <RecaptchaBox>
                  <ReCAPTCHA
                    sitekey={process.env.REACT_APP_SITE_KEY || ''}
                    ref={captchaRef}
                    onChange={onCaptchaChange}
                    size="normal"
                  />
                </RecaptchaBox>
                <ButtonDiv>
                  <Button
                    type="submit"
                    fullWidth
                    variant="contained"
                    disabled={!captchaToken}>
                    {t('signUp')}
                  </Button>
                </ButtonDiv>
              </form>
              <LinkDiv>
                <Link to="/">{t('backToLogin')}</Link>
              </LinkDiv>
            </MainBox>
          </FormContainer>
        </Paper>
      </MainDivBox>
    </Fragment>
  );
};
export default Signup;
