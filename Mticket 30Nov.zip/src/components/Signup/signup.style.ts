import { makeStyles, styled } from '@mui/styles';
export const useStyles: any = makeStyles((theme: any) => ({
  selectControl: {
    marginTop: '0.5rem',
    minWidth: '48.5%',
  },

  selectInput: {
    marginTop: '-0.5rem',
  },
}));

export const MainDivBox = styled('div')({
  minWidth: '33rem',
  padding: '0.5rem',
});

export const FormContainer = styled('div')({
  padding: '1rem',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
});

export const MainBox = styled('div')({
  marginTop: '1rem',
});

export const Heading = styled('div')({
  fontSize: '1.5rem',
  fontWeight: '600',
});

export const ButtonDiv = styled('div')({
  marginTop: '1.5rem',
  marginBottom: '1rem',
});

export const LinkDiv = styled('div')({
  textAlign: 'center',
  fontStyle: 'italic',
});

export const RecaptchaBox = styled('div')({
  marginTop: '1rem',
  display: 'flex',
  justifyContent: 'center',
});

export const Row = styled('div')({
  display: 'flex',
  flexDirection: 'row',
  gap: '1rem',
});
