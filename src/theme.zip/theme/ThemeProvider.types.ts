import { PropsWithChildren } from "react";

export interface IMuiThemeProviderProps extends PropsWithChildren{}