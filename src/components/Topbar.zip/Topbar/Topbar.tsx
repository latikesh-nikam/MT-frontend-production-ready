import { useContext } from 'react';

import { ILocalisationContext } from '../../hoc/Localization/localisationProvider.types';

import { Header } from './topbar.style';

import Profile from '../Profile/Profile';
import { LocalisationContext } from '../../hoc/Localization/LocalisationProvider';

import { Box } from '@mui/material';
import DirectionsBusFilledIcon from '@mui/icons-material/DirectionsBusFilled';

function Topbar() {
  const { localisation, updateLocalisation } = useContext(
    LocalisationContext,
  ) as ILocalisationContext;
  const { localString } = localisation;
  return (
    <Header>
      <Box className="logoDiv">
        <DirectionsBusFilledIcon className="icon" />
        <h2>{localString?.Mticket}</h2>
      </Box>
      <Profile />
    </Header>
  );
}
export default Topbar;
