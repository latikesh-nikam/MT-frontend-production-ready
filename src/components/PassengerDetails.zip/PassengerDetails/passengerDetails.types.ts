export default interface IPassengerDetailsProps {
  name: string;
  email: string;
  phone: number | string;
  gender: string;
  age: string;
}
